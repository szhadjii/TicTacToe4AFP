"""ÁL-BACKEND a frontend kipróbálásához. A valódi backend (app.py + game.py) helyett használd,
amíg a társaid kódja nem készül el.   Futtatás:  pip install flask  ->  python mock_app.py
"""
from flask import Flask, jsonify, request, render_template
 
app = Flask(__name__)
G = {}
 
def new(size):
    G.update(size=size, table=[["" for _ in range(size)] for _ in range(size)],
             next="X", status="folyamatban", win=[])
 
def winner(t, n, k, r, c, p):
    for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
        line = [(r, c)]
        for s in (1, -1):
            rr, cc = r + dr * s, c + dc * s
            while 0 <= rr < n and 0 <= cc < n and t[rr][cc] == p:
                line.append((rr, cc)); rr += dr * s; cc += dc * s
        if len(line) >= k:
            return [list(x) for x in line]
    return []
 
def view():
    return jsonify(table=G["table"], size=G["size"], next=G["next"] if G["status"] == "folyamatban" else None,
                   status=G["status"], winning_fields=G["win"])
 
def err(code, msg):
    return jsonify(error=msg), code
 
new(3)
 
@app.get("/")
def index():
    return render_template("index.html")
 
@app.get("/state")
def state():
    return view()
 
@app.post("/new-game")
def new_game():
    size = (request.get_json(silent=True) or {}).get("size")
    if size not in (3, 5):
        return err(400, "size")
    new(size)
    return view()
 
@app.post("/turn")
def turn():
    d = request.get_json(silent=True) or {}
    r, c, n, t = d.get("row"), d.get("column"), G["size"], G["table"]
    if G["status"] != "folyamatban":
        return err(409, "game_over")
    if not (isinstance(r, int) and isinstance(c, int) and 0 <= r < n and 0 <= c < n):
        return err(400, "out_of_range")
    if t[r][c]:
        return err(409, "occupied")
    p = G["next"]
    t[r][c] = p
    k = 3 if n == 3 else 4  # 5x5: 4 egymás mellett (nyitott kérdés a specben)
    G["win"] = winner(t, n, k, r, c, p)
    if G["win"]:
        G["status"] = f"{p} nyert"
    elif all(x for row in t for x in row):
        G["status"] = "döntetlen"
    else:
        G["next"] = "O" if p == "X" else "X"
    return view()
 
if __name__ == "__main__":
    app.run(debug=True)